// thunk call to fetch movie list
const getMovieData = () => ({});

// action object for filter  feature

const filterByGenre = () => ({});
