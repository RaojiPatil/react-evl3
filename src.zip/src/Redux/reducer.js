

const initState = {
    data:[],
    filterData:[],
    isLoading:false,
    isError:false
}

export const Reducer = ()=>{
    // add the switch statement for different actions
}