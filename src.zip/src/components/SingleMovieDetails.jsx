export const SingleMovieDetails = () => {


    // make a request to get the details
  return <></>;
};
